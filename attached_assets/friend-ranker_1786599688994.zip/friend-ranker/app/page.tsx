"use client"

import { useMemo, useState } from "react"
import {
  dealRound,
  scoreEighth,
  scoreAdjective,
  buildWordPool,
  type RoundDeal,
  type Phase,
} from "@/lib/game"
import { SetupScreen } from "@/components/setup-screen"
import { GameHeader } from "@/components/game-header"
import { HandoffScreen } from "@/components/handoff-screen"
import { RankStage } from "@/components/rank-stage"
import { EighthStage } from "@/components/eighth-stage"
import { GuessStage } from "@/components/guess-stage"
import { RevealStage } from "@/components/reveal-stage"
import { GameOverScreen } from "@/components/gameover-screen"

interface Team {
  name: string
  score: number
}

export default function Page() {
  const poolSize = useMemo(() => buildWordPool().length, [])

  const [phase, setPhase] = useState<Phase>("setup")
  const [teams, setTeams] = useState<[Team, Team]>([
    { name: "Team Violet", score: 0 },
    { name: "Team Lime", score: 0 },
  ])
  const [totalRounds, setTotalRounds] = useState(6)
  const [turnIndex, setTurnIndex] = useState(0)

  const [deal, setDeal] = useState<RoundDeal | null>(null)
  const [rankOrder, setRankOrder] = useState<string[]>([]) // 7 words (rank phase)
  const [eighthOrder, setEighthOrder] = useState<string[]>([]) // 8 items, true order
  const [guessOrder, setGuessOrder] = useState<string[]>([]) // 8 items, guess order
  const [guessAdjective, setGuessAdjective] = useState<string | null>(null)

  // Same team ranks (via a representative) and guesses. Teams compete on
  // cumulative score across alternating turns.
  const activeTeam = (turnIndex % 2) as 0 | 1
  const round = turnIndex + 1
  const isLastRound = round >= totalRounds

  function beginTurn() {
    const d = dealRound()
    setDeal(d)
    setRankOrder(d.words)
    setEighthOrder([])
    setGuessOrder([])
    setGuessAdjective(null)
    setPhase("handoff-rank")
  }

  function startGame(config: { teamNames: [string, string]; rounds: number }) {
    setTeams([
      { name: config.teamNames[0], score: 0 },
      { name: config.teamNames[1], score: 0 },
    ])
    setTotalRounds(config.rounds)
    setTurnIndex(0)
    beginTurn()
  }

  function confirmRanking() {
    if (!deal) return
    setEighthOrder([...rankOrder, deal.eighthWord])
    setPhase("eighth-place")
  }

  function confirmEighth() {
    if (!deal) return
    // The rest of the team sees the representative's true 7-word order (locked,
    // but with the adjective still hidden) plus the 8th word to place.
    const sevenInOrder = eighthOrder.filter((w) => w !== deal.eighthWord)
    setGuessOrder([...sevenInOrder, deal.eighthWord])
    setPhase("handoff-guess")
  }

  function confirmGuess() {
    if (!deal || !guessAdjective) return
    const trueEighthPos = eighthOrder.indexOf(deal.eighthWord)
    const guessEighthPos = guessOrder.indexOf(deal.eighthWord)
    const pts =
      scoreEighth(trueEighthPos, guessEighthPos) +
      scoreAdjective(deal.adjective, guessAdjective)

    setTeams((prev) => {
      const next = [...prev] as [Team, Team]
      next[activeTeam] = {
        ...next[activeTeam],
        score: next[activeTeam].score + pts,
      }
      return next
    })
    setPhase("reveal")
  }

  function continueFromReveal() {
    if (isLastRound) {
      setPhase("gameover")
    } else {
      setTurnIndex((i) => i + 1)
      beginTurn()
    }
  }

  // ---- Rendering ----

  if (phase === "setup") {
    return <SetupScreen onStart={startGame} poolSize={poolSize} />
  }

  if (phase === "gameover") {
    return <GameOverScreen teams={teams} onPlayAgain={() => setPhase("setup")} />
  }

  return (
    <main className="min-h-dvh">
      <GameHeader
        teams={teams}
        round={round}
        totalRounds={totalRounds}
        activeTeam={activeTeam}
      />

      {phase === "handoff-rank" && (
        <HandoffScreen
          teamName={teams[activeTeam].name}
          title="Pick one representative"
          detail="Your representative alone holds the device and looks at the screen. Everyone else on the team, look away — you'll be reading their mind in a moment."
          buttonLabel="I'm the representative — show me"
          onContinue={() => setPhase("rank")}
        />
      )}

      {phase === "rank" && deal && (
        <RankStage
          teamName={teams[activeTeam].name}
          adjective={deal.adjective}
          order={rankOrder}
          onReorder={setRankOrder}
          onConfirm={confirmRanking}
        />
      )}

      {phase === "eighth-place" && deal && (
        <EighthStage
          teamName={teams[activeTeam].name}
          adjective={deal.adjective}
          eighthWord={deal.eighthWord}
          order={eighthOrder}
          onReorder={setEighthOrder}
          onConfirm={confirmEighth}
        />
      )}

      {phase === "handoff-guess" && (
        <HandoffScreen
          teamName={teams[activeTeam].name}
          title="Now read your representative's mind"
          detail="Representative, hand the device to the rest of your team and stay quiet. Their ranking is locked but the adjective is hidden — slot in the surprise 8th word, then guess which adjective was their secret axis."
          buttonLabel="We're ready — show the ranking"
          onContinue={() => setPhase("guess")}
        />
      )}

      {phase === "guess" && deal && (
        <GuessStage
          teamName={teams[activeTeam].name}
          eighthWord={deal.eighthWord}
          order={guessOrder}
          onReorder={setGuessOrder}
          adjectiveChoices={deal.adjectiveChoices}
          selectedAdjective={guessAdjective}
          onSelectAdjective={setGuessAdjective}
          onConfirm={confirmGuess}
        />
      )}

      {phase === "reveal" && deal && guessAdjective && (
        <RevealStage
          teamName={teams[activeTeam].name}
          adjective={deal.adjective}
          trueOrder={eighthOrder}
          eighthWord={deal.eighthWord}
          trueEighthPos={eighthOrder.indexOf(deal.eighthWord)}
          guessEighthPos={guessOrder.indexOf(deal.eighthWord)}
          guessAdjective={guessAdjective}
          eighthPoints={scoreEighth(
            eighthOrder.indexOf(deal.eighthWord),
            guessOrder.indexOf(deal.eighthWord),
          )}
          adjectivePoints={scoreAdjective(deal.adjective, guessAdjective)}
          isLastRound={isLastRound}
          onContinue={continueFromReveal}
        />
      )}
    </main>
  )
}
