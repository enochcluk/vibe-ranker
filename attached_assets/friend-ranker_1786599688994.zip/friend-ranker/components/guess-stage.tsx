"use client"

import { Button } from "@/components/ui/button"
import { RankBoard } from "@/components/rank-board"
import { ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface GuessStageProps {
  teamName: string
  eighthWord: string
  order: string[] // Team A's 7 words (locked) + the 8th word, current guess order
  onReorder: (next: string[]) => void
  adjectiveChoices: string[]
  selectedAdjective: string | null
  onSelectAdjective: (adj: string) => void
  onConfirm: () => void
}

export function GuessStage({
  teamName,
  eighthWord,
  order,
  onReorder,
  adjectiveChoices,
  selectedAdjective,
  onSelectAdjective,
  onConfirm,
}: GuessStageProps) {
  return (
    <div className="mx-auto max-w-2xl px-4 pb-28 pt-5">
      <div className="mb-5 rounded-3xl border border-border bg-card p-5">
        <h2 className="font-display text-2xl font-bold text-balance">
          {teamName}, crack the spectrum
        </h2>
        <p className="mt-2 text-pretty text-sm leading-relaxed text-muted-foreground">
          Below is the other team&apos;s locked ranking. Figure out the hidden
          logic, then do two things:
        </p>
        <ol className="mt-3 space-y-1.5 text-sm">
          <li className="flex gap-2">
            <span className="font-display font-bold text-primary">1.</span>
            Drag{" "}
            <span className="font-semibold text-foreground">{eighthWord}</span>{" "}
            into the slot where you think they placed it.
          </li>
          <li className="flex gap-2">
            <span className="font-display font-bold text-primary">2.</span>
            Pick which adjective you think was their secret axis.
          </li>
        </ol>
      </div>

      <RankBoard
        items={order}
        onReorder={onReorder}
        lowLabel="least"
        highLabel="most"
        movableId={eighthWord}
        highlightId={eighthWord}
      />

      <div className="mt-8">
        <h3 className="mb-3 font-display text-lg font-bold">
          Which adjective was it?
        </h3>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {adjectiveChoices.map((adj) => {
            const selected = selectedAdjective === adj
            return (
              <button
                key={adj}
                type="button"
                onClick={() => onSelectAdjective(adj)}
                className={cn(
                  "rounded-2xl border px-3 py-3.5 text-center font-display text-base font-bold lowercase transition-colors",
                  selected
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card hover:border-primary/50",
                )}
                aria-pressed={selected}
              >
                {adj}
              </button>
            )
          })}
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/90 px-4 py-3 backdrop-blur">
        <div className="mx-auto max-w-2xl">
          <Button
            onClick={onConfirm}
            disabled={!selectedAdjective}
            className="h-13 w-full rounded-2xl py-3.5 text-base font-bold"
          >
            {selectedAdjective ? "Reveal the answer" : "Pick an adjective first"}
            <ArrowRight className="ml-1 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
