"use client"

import { Button } from "@/components/ui/button"
import { Check, X, ArrowRight, Trophy } from "lucide-react"
import { cn } from "@/lib/utils"

interface RevealStageProps {
  teamName: string
  adjective: string
  trueOrder: string[] // 8 items in the ranking team's true order
  eighthWord: string
  trueEighthPos: number
  guessEighthPos: number
  guessAdjective: string
  eighthPoints: number
  adjectivePoints: number
  isLastRound: boolean
  onContinue: () => void
}

export function RevealStage({
  teamName,
  adjective,
  trueOrder,
  eighthWord,
  trueEighthPos,
  guessEighthPos,
  guessAdjective,
  eighthPoints,
  adjectivePoints,
  isLastRound,
  onContinue,
}: RevealStageProps) {
  const total = eighthPoints + adjectivePoints
  const adjectiveRight = guessAdjective === adjective
  const distance = Math.abs(trueEighthPos - guessEighthPos)

  return (
    <div className="mx-auto max-w-2xl px-4 pb-28 pt-5">
      <div className="rounded-3xl border border-primary/40 bg-primary/10 p-6 text-center">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {guessingTeamName} scored
        </p>
        <p className="font-display text-6xl font-bold leading-none">
          +{total}
        </p>
        <p className="mt-2 text-sm text-muted-foreground">points this round</p>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <ResultCard
          title="8th word"
          points={eighthPoints}
          correct={distance === 0}
        >
          Placed{" "}
          <span className="font-semibold text-foreground">{eighthWord}</span> at
          slot {guessEighthPos + 1}; true slot was {trueEighthPos + 1}
          {distance === 0 ? " — exact!" : ` — off by ${distance}.`}
        </ResultCard>
        <ResultCard
          title="Adjective"
          points={adjectivePoints}
          correct={adjectiveRight}
        >
          Guessed{" "}
          <span className="font-semibold lowercase text-foreground">
            {guessAdjective}
          </span>
          . The secret axis was{" "}
          <span className="font-semibold lowercase text-foreground">
            {adjective}
          </span>
          .
        </ResultCard>
      </div>

      <div className="mt-6">
        <h3 className="mb-1 font-display text-lg font-bold">
          {rankingTeamName}&apos;s true ranking
        </h3>
        <p className="mb-3 text-sm text-muted-foreground">
          least{" "}
          <span className="lowercase text-foreground">{adjective}</span> → most{" "}
          <span className="lowercase text-foreground">{adjective}</span>
        </p>
        <ol className="flex flex-col gap-2">
          {trueOrder.map((word, i) => {
            const isEighth = word === eighthWord
            const isGuessSlot = i === guessEighthPos
            return (
              <li
                key={word}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border px-3 py-3 sm:px-4",
                  isEighth
                    ? "border-primary/70 bg-primary/10"
                    : "border-border bg-card",
                )}
              >
                <span
                  className={cn(
                    "flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-display text-sm font-bold tabular-nums",
                    isEighth
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground",
                  )}
                >
                  {i + 1}
                </span>
                <span className="flex-1 text-pretty font-medium leading-snug">
                  {word}
                  {isEighth && (
                    <span className="ml-2 rounded-full bg-primary/20 px-2 py-0.5 align-middle text-[11px] font-semibold text-primary">
                      8th word
                    </span>
                  )}
                </span>
                {isGuessSlot && (
                  <span className="shrink-0 rounded-full border border-accent/50 px-2 py-0.5 text-[11px] font-semibold text-accent">
                    guessed here
                  </span>
                )}
              </li>
            )
          })}
        </ol>
      </div>

      <div className="mt-6 rounded-2xl border border-dashed border-border bg-card/50 p-4 text-center">
        <p className="text-sm font-medium">
          {rankingTeamName}: explain your interpretation of{" "}
          <span className="lowercase text-primary">{adjective}</span> out loud.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          Defend the most unhinged placement on the board.
        </p>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-background/90 px-4 py-3 backdrop-blur">
        <div className="mx-auto max-w-2xl">
          <Button
            onClick={onContinue}
            className="h-13 w-full rounded-2xl py-3.5 text-base font-bold"
          >
            {isLastRound ? (
              <>
                See final results
                <Trophy className="ml-1 h-5 w-5" />
              </>
            ) : (
              <>
                Next round
                <ArrowRight className="ml-1 h-5 w-5" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}

function ResultCard({
  title,
  points,
  correct,
  children,
}: {
  title: string
  points: number
  correct: boolean
  children: React.ReactNode
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {title}
        </span>
        <span
          className={cn(
            "flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-bold",
            correct
              ? "bg-accent/20 text-accent"
              : points > 0
                ? "bg-primary/15 text-primary"
                : "bg-secondary text-muted-foreground",
          )}
        >
          {correct ? (
            <Check className="h-3.5 w-3.5" />
          ) : points === 0 ? (
            <X className="h-3.5 w-3.5" />
          ) : null}
          +{points}
        </span>
      </div>
      <p className="text-sm leading-relaxed text-muted-foreground">{children}</p>
    </div>
  )
}
