import { WORDS, ADJECTIVES, PARTICIPANTS } from "./word-bank"

export const WORDS_PER_ROUND = 7
export const ADJECTIVE_CHOICES = 5

/** Points for the 8th-word insertion, keyed by |guess - truth|. */
const EIGHTH_WORD_POINTS = [5, 3, 1] // exact, off-by-1, off-by-2; farther = 0
export const ADJECTIVE_POINTS = 5

export type Phase =
  | "setup"
  | "handoff-rank" // pass to the ranking team
  | "rank" // ranking team orders 7 words
  | "eighth-place" // ranking team places the drawn 8th word
  | "handoff-guess" // pass to the guessing team
  | "guess" // guessing team inserts 8th word + picks adjective
  | "reveal" // scores + explanation
  | "gameover"

export interface RoundDeal {
  words: string[] // the 7 drawn words (draw order, not ranked)
  eighthWord: string // the surprise 8th word
  adjective: string // the true secret adjective
  adjectiveChoices: string[] // shuffled candidates shown to the guessers
}

export interface RoundResult {
  dealIndex: number
  rankingTeam: 0 | 1
  guessingTeam: 0 | 1
  adjective: string
  ranking: string[] // ranking team's final 7-word order (least -> most)
  eighthWord: string
  trueEighthPos: number // 0-based index where ranking team placed it
  guessEighthPos: number // 0-based index the guessing team chose
  guessAdjective: string
  eighthPoints: number
  adjectivePoints: number
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

function sampleUnique<T>(arr: T[], n: number): T[] {
  return shuffle(arr).slice(0, n)
}

/** Build the full noun pool: base words + any party participants. */
export function buildWordPool(): string[] {
  return [...WORDS, ...PARTICIPANTS]
}

/** Draw a fresh round: 7 words + an 8th word + a secret adjective + decoys. */
export function dealRound(): RoundDeal {
  const pool = buildWordPool()
  const picks = sampleUnique(pool, WORDS_PER_ROUND + 1)
  const words = picks.slice(0, WORDS_PER_ROUND)
  const eighthWord = picks[WORDS_PER_ROUND]

  const adjPicks = sampleUnique(ADJECTIVES, ADJECTIVE_CHOICES)
  // Guarantee the true adjective is in the candidate list.
  let adjectiveChoices = adjPicks
  const adjective = adjPicks[0]
  adjectiveChoices = shuffle(adjPicks)

  return { words, eighthWord, adjective, adjectiveChoices }
}

/** Score the 8th-word insertion by distance from the true slot. */
export function scoreEighth(truePos: number, guessPos: number): number {
  const d = Math.abs(truePos - guessPos)
  return EIGHTH_WORD_POINTS[d] ?? 0
}

export function scoreAdjective(truth: string, guess: string): number {
  return truth === guess ? ADJECTIVE_POINTS : 0
}

export const MAX_ROUND_POINTS = EIGHTH_WORD_POINTS[0] + ADJECTIVE_POINTS
