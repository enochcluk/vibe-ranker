/**
 * ============================================================================
 *  SECRET SPECTRUM — WORD BANK
 * ============================================================================
 *
 *  This is the ONE file you edit to change the game's content.
 *
 *  HOW TO EDIT
 *  -----------
 *  1. Add or remove entries from any list below. Keep them as quoted strings
 *     separated by commas, e.g.  "Pineapple",
 *  2. To add the people at your party, drop their names into PARTICIPANTS.
 *     They get mixed straight into the draw pile, so you'll see friends'
 *     names ranked as "most corporate" or "most haunted".
 *  3. Save the file — the game picks up your changes on the next round.
 *
 *  TIPS FOR GOOD ROUNDS
 *  --------------------
 *  - Concrete nouns and proper nouns cause the most arguing. Mix brands,
 *    animals, places, foods, fictional characters, and people.
 *  - Adjectives should be VAGUE and interpretable. "corporate", "haunted",
 *    and "trustworthy" spark debate. "blue" or "large" do not.
 *  - More variety = more absurd, more fun.
 * ============================================================================
 */

/** Add the names of people at your party here. They get shuffled into the draw pile. */
export const PARTICIPANTS: string[] = [
  // "Alex",
  // "Priya",
  // "Sam",
]

/** The big pile of nouns players will rank. Add freely. */
export const WORDS: string[] = [
  // Brands & companies
  "Costco", "Ferrari", "LinkedIn", "Crocs", "IKEA", "Nintendo", "Rolex", "WD-40",
  "Nokia", "Tupperware", "Red Bull", "Lego", "Harley-Davidson", "Dyson", "Nescafé",
  "PayPal", "Segway", "GoPro", "Peloton", "Roomba",

  // Places
  "Antarctica", "Ohio", "The Moon", "Dubai", "A gas station", "Times Square",
  "A haunted mansion", "The DMV", "A parking garage", "Venice", "A ball pit",
  "The Bermuda Triangle", "A cul-de-sac", "Area 51", "A hot spring", "Narnia",
  "The break room", "A submarine",

  // Animals
  "Golden Retriever", "Raccoon", "Axolotl", "Pigeon", "Praying mantis", "Manatee",
  "Goose", "Ferret", "Octopus", "Alpaca", "Hedgehog", "Peacock", "Naked mole rat",
  "Corgi", "Seagull", "Capybara", "Tarantula", "Blobfish",

  // Fictional / characters
  "SpongeBob", "Batman", "Shrek", "Gandalf", "A Roomba with a knife", "Barbie",
  "The Michelin Man", "Sauron", "Waldo", "A Sim", "Clippy", "A garden gnome",
  "The Kool-Aid Man", "Bigfoot", "A mall Santa",

  // Food & drink
  "A gas station hot dog", "Kombucha", "Fondue", "A raw oyster", "Cold pizza",
  "Wonder Bread", "Truffle oil", "A protein bar", "Boxed wine", "Gummy bears",
  "Instant ramen", "A charcuterie board", "Tap water", "A wedding cake",

  // Objects & concepts
  "A fax machine", "A weighted blanket", "A lava lamp", "A spreadsheet",
  "Bubble wrap", "A trench coat", "A rubber duck", "A traffic cone", "A monocle",
  "A trampoline", "A shredder", "A leaf blower", "A fanny pack", "A yacht",
  "A vending machine", "A group chat", "A fire drill", "A voicemail",
  "A motivational poster", "A power nap", "A conference call", "A ceiling fan",

  // People-ish roles
  "A substitute teacher", "A used car salesman", "A yoga instructor",
  "A night-shift security guard", "A wedding DJ", "A life coach", "An intern",
  "A cruise ship captain", "A door-to-door vacuum salesman",
]

/**
 * Vague, interpretable adjectives. One is drawn as the SECRET axis each round.
 * The guessing team also gets shown a few decoys from this list.
 */
export const ADJECTIVES: string[] = [
  "corporate", "haunted", "trustworthy", "chaotic", "expensive", "wholesome",
  "sketchy", "romantic", "dangerous", "nostalgic", "powerful", "lonely",
  "suspicious", "elegant", "delicious", "ancient", "rebellious", "cozy",
  "overrated", "dramatic", "mysterious", "innocent", "aggressive", "sophisticated",
  "cursed", "professional", "unhinged", "majestic", "flammable", "photogenic",
  "punctual", "greedy", "spiritual", "athletic", "villainous", "underappreciated",
  "high-maintenance", "trending", "forgettable", "menacing", "comforting",
  "bureaucratic", "feral", "luxurious", "wise", "petty", "iconic", "gullible",
]
